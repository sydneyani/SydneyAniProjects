# Visionary-Solutions Backend
Go to backend directory 
```cd your-project```
Install the required dependencies by running
```npm install```
To start the project in development mode, use
```npm run dev```
Or to run without development mode, run
```npm start```

To access the API, open a web browser and navigate to `http://localhost:8080`